---
name: compress
description: >
  Save a structured session log before ending or when context window is filling up.
  Captures key learnings, decisions, file changes, and next steps into a timestamped
  markdown file under CC-Session-Logs/. Use before closing a session or when you feel
  context is getting large.
---

# /compress — Session Context Snapshot

## Instructions

When this command is invoked, perform the following steps **without asking the user any questions**:

### 1. Detect project root
```bash
PROJECT_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || pwd)
LOG_DIR="${PROJECT_ROOT}/CC-Session-Logs"
mkdir -p "$LOG_DIR"
```

### 2. Generate timestamp and topic
- Timestamp: `YYYYMMDD-HHmmss` format
- Topic: auto-generate a 3-5 word kebab-case summary of this session's main work
- Filename: `{timestamp}_{topic}.md`

### 3. Write structured session log

Create the file with this structure:

```markdown
# Session Log: {topic}
**Date:** {YYYY-MM-DD HH:MM}
**Duration:** ~{estimate}

## Summary
<!-- 2-3 sentence overview of what was accomplished -->

## Key Decisions
<!-- Bullet list of decisions made and why -->

## Files Modified
<!-- List of files touched with brief description of changes -->
- `path/to/file.cpp` — added XYZ handler
- `path/to/config.sh` — updated connection params

## Problems Solved
<!-- Debugging findings, root causes identified -->

## Unfinished / Next Steps
<!-- What's left to do, any blockers -->
- [ ] task 1
- [ ] task 2

## Important Context
<!-- Anything that would be painful to rediscover -->
<!-- API quirks, workarounds, env-specific gotchas -->

---
<!-- RAW SESSION LOG (below this line is for searchability, not loaded by /resume) -->
```

### 4. Update CLAUDE.md
After writing the log, update the "Active Tasks" and "Known Issues" sections in
`CLAUDE.md` to reflect current state.

### 5. Confirm
Print: `✅ Session compressed → CC-Session-Logs/{filename}`
