---
name: resume
description: >
  Restore context from previous sessions. Reads CLAUDE.md for project state and
  recent session logs for work history. Use at the start of a new session to
  pick up where you left off.
---

# /resume — Restore Session Context

## Instructions

When this command is invoked:

### 1. Detect project root and log directory
```bash
PROJECT_ROOT=$(git rev-parse --show-toplevel 2>/dev/null || pwd)
LOG_DIR="${PROJECT_ROOT}/CC-Session-Logs"
```

### 2. Load project-level context
Read `${PROJECT_ROOT}/CLAUDE.md` — this contains persistent project state,
tech stack info, active tasks, and key decisions.

### 3. Load recent session logs
```bash
# Get the 2 most recent session logs (by filename timestamp)
ls -t "${LOG_DIR}"/*.md 2>/dev/null | head -2
```

For each log file, read **only the content above** the `<!-- RAW SESSION LOG -->` marker.
This is the structured summary — skip everything below that line to save tokens.

### 4. Assess git state
```bash
git status --short
git log --oneline -5
git diff --stat
```

### 5. Present a brief status report

Format:
```
📋 Session Resumed
━━━━━━━━━━━━━━━━━
**Project:** {project name from CLAUDE.md}
**Branch:** {current branch}
**Last session:** {date} — {topic from latest log}

**Unfinished tasks:**
- [ ] {from latest log's "Next Steps"}

**Uncommitted changes:**
{git status summary}

Ready to continue. What should we work on?
```

### 6. Do NOT summarize everything
Keep the status report concise. You now have the full context loaded —
demonstrate it by being ready to work, not by reciting everything back.
