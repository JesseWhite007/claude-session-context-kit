---
name: preserve
description: >
  Update CLAUDE.md with key learnings from the current session.
  Use mid-session when you've made an important discovery or decision
  that should persist across all future sessions.
---

# /preserve — Persist Key Knowledge to CLAUDE.md

## Instructions

When this command is invoked:

### 1. Identify what to preserve
Scan the current conversation for:
- **Architecture/design decisions** with rationale
- **API quirks or gotchas** discovered through debugging
- **Environment-specific configurations** that were hard to figure out
- **Corrections** to previously held assumptions

### 2. Update CLAUDE.md sections
Open `CLAUDE.md` and append to the appropriate sections:
- New decisions → "Key Decisions"
- New blockers → "Known Issues / Blockers"
- Task progress → "Active Tasks" (check off completed, add new)

### 3. Avoid duplication
Before adding, check if the information already exists in CLAUDE.md.
If it does, update the existing entry rather than duplicating.

### 4. Confirm
Print: `✅ Preserved {N} items to CLAUDE.md`
List what was added/updated.
